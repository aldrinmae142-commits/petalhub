<?php
// PetalHub settings. The defaults match a fresh XAMPP install (MySQL user "root" with no password).
define('DB_HOST', '127.0.0.1');
define('DB_PORT', 3306);
define('DB_NAME', 'petalhub');
define('DB_USER', 'root');
define('DB_PASS', '');            // put your MySQL root password here if you set one

// The admin account is created automatically on first app use if the database has no admin.
define('ADMIN_EMAIL', 'admin@petalhub.com');
define('ADMIN_PASSWORD', 'petalhub2026');  

define('PH_TIMEZONE', 'Asia/Manila');

// Set a unique random value of at least 32 characters only while running setup.php, then clear it.
define('PH_SETUP_TOKEN', '');

// true = when something goes wrong the page shows the real reason (easy to screenshot and report). Set to false when everything works.
define('PH_DEBUG', true);
