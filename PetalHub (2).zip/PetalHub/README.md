# PetalHub - Online Flower Ordering System
PHP + MySQL on **XAMPP** (Apache + MySQL + phpMyAdmin). No Node.js needed.

## Setup
1. Open the **XAMPP Control Panel** and **Start Apache** and **Start MySQL**.
2. Copy this folder to `C:\xampp\htdocs\` so you get `C:\xampp\htdocs\PetalHub\index.html`
   (you can rename the folder, for example to `petalhub`).
3. Open http://localhost/phpmyadmin > **Import** > choose `schema.sql` > **Go**.
   For an existing PetalHub database, do not import over it; back it up and use the one-time setup step below.
4. In `config.php`, enter the database and admin settings. Set `PH_SETUP_TOKEN` to a unique random value of at least 32 characters (a password manager can generate one).
5. Open **http://localhost/PetalHub/setup.php**, enter the token and run setup. This applies missing migrations without deleting or resetting existing records.
6. Clear `PH_SETUP_TOKEN` in `config.php`, remove `setup.php` from the web root, then open **http://localhost/PetalHub/** and press **Ctrl + Shift + R**.

## Accounts
- **Admin:** `admin@petalhub.com` / `petalhub2026` (created automatically on first app use if no admin exists; set a private password in `config.php` before deploying).
- **Customer:** Log in > Create account.
- **Forgot password:** Customers can request a six-digit Brevo SMTP code, valid for 10 minutes. Codes allow three incorrect attempts, and a new code is available after a 60-second cooldown. The verified reset session can be used once.
- **Flower catalog:** Names, prices, descriptions, images, and stock are loaded from the MySQL `products` table. Product edits are reflected on customer pages when they load and refreshed while browsing.

## Flower catalog data
The existing `GET /api/products` endpoint supplies the customer catalog, and the admin uses the same product records to add, edit, and delete flowers. Product IDs stay unchanged so orders and recommendations keep their links. No product table or records are duplicated.

For an existing database, run the protected `setup.php` migration after deploying this update. It adds the `products.description` column if needed and fills blank descriptions and image paths for the original flower IDs only; it does not overwrite nonblank catalog values. New installations get the description column and starter catalog from `schema.sql`.

Event and weather recommendation choices already use the `events`, `weathers`, `event_products`, and `weather_products` tables. Wrapping designs do not have a database table, so their presentation details remain in `js/shop-data.js`; event dates/messages and weather descriptions also remain there.

## Frontend files
- `js/customer.js` contains the storefront, customer account, cart, checkout, and shared app startup.
- `js/admin.js` contains the admin dashboard screen and admin actions.
- `js/shop-data.js` contains static recommendation and wrapping data.
- `css/customer.css` contains shared and customer-facing styles; `css/admin.css` contains admin dashboard and management-form styles.

## Password reset email (Brevo)
1. In `smtp-config.php`, enter the SMTP login and SMTP key from your Brevo account. These are separate from your Brevo website login. The sender is configured as **PetalHub** / `aldrinmae142@gmail.com`; verify that sender in Brevo before sending. Never share or commit your SMTP key.
2. Keep `smtp-config.php` in the same folder as `api.php`. `.htaccess` blocks direct web access to it and to the bundled `vendor` libraries.
3. Existing databases need only this additional table. Run in phpMyAdmin with the `petalhub` database selected:

   ```sql
   CREATE TABLE IF NOT EXISTS password_reset_codes (
     user_id INT PRIMARY KEY,
     code_hash VARCHAR(255) NOT NULL,
     expires_at DATETIME NOT NULL,
     attempts TINYINT UNSIGNED NOT NULL DEFAULT 0,
     requested_at DATETIME NOT NULL,
     reset_token_hash CHAR(64) NULL,
     reset_expires_at DATETIME NULL,
     FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
     INDEX idx_password_reset_expires_at (expires_at)
   );
   ```

   The same table is included in `schema.sql` for new installations. No existing account columns or records need to be changed. If `password_reset_codes` already exists from an older reset attempt, rerun the protected `setup.php` migration (with a temporary `PH_SETUP_TOKEN`) so it adds the two reset-session columns. Alternatively, if only those columns are missing, run:

   ```sql
   ALTER TABLE password_reset_codes
     ADD COLUMN reset_token_hash CHAR(64) NULL,
     ADD COLUMN reset_expires_at DATETIME NULL;
   ```

## GCash QR payments - set up before you present
1. Log in as admin > **Dashboard > Payments**.
2. **Choose a QR image**: upload the QR code from your own GCash app (GCash > QR > save it to your photos), then press **Use this QR code**.
   The QR code that comes with the project is only a **SAMPLE** and will not pay anyone.
3. Fill in **Account name** and **GCash mobile number** and press **Save account details**.
4. When a customer pays with GCash, the order appears under **Orders > Verify payment**. Check the reference number and amount in your GCash
   transactions, then press **Verify payment** (or **Reject payment**). See `REVISIONS.md` for the whole flow.

The `payments` folder must be writable (it is by default on XAMPP for Windows). Receipt screenshots are saved in `payments/proofs`, which cannot be opened by a direct link.

## Settings (`config.php`)
MySQL user/password (XAMPP default is `root` with no password), admin email/password, timezone, one-time setup token, and `PH_DEBUG`. Brevo SMTP settings are stored separately in `smtp-config.php`.
(shows diagnostic details when something goes wrong; set it to `false` on a public deployment).

## Deploying to InfinityFree or another PHP/MySQL host
1. Create a MySQL database in the hosting control panel and import `schema.sql` using its phpMyAdmin. If the host rejects `CREATE DATABASE` or `USE`, remove those two statements from an import copy and import into the database the host created.
2. Set the supplied database host, database name, user and password in `config.php`; do not use the XAMPP defaults.
3. Configure the admin password and a temporary random `PH_SETUP_TOKEN` (at least 32 characters), upload the PHP files and the rest of the site, including `smtp-config.php` and the bundled `vendor/phpmailer/phpmailer/src` files, then run `https://your-site/setup.php`.
4. After successful setup, clear `PH_SETUP_TOKEN` and delete `setup.php` from the public web root. Set `PH_DEBUG` to `false`. Keep `payments` writable for QR images and payment proofs.
5. Run the password-reset table SQL above in phpMyAdmin if this is an existing database; new databases get the table from `schema.sql`.
6. Enter Brevo SMTP credentials into `smtp-config.php` on the host. Verify `aldrinmae142@gmail.com` as a sender in Brevo. Keep `.htaccess` in place to block web access to SMTP settings and the bundled library.
7. Test customer signup/login, forgot-password email, admin login, ordering, GCash proof upload, inventory changes, and rider/product deletion. Take regular database and uploaded-file backups.

The application no longer runs migrations or reads `information_schema` during ordinary API requests. Setup is explicit and repeatable; it uses `CREATE TABLE IF NOT EXISTS` and checks before adding columns, indexes, or constraints. The PHP migration preserves orders and accounts. Deleting a flower clears only its product link in old order items; the saved name and price remain.

## Troubleshooting
| You see | What to do |
|---|---|
| "Cannot reach the PetalHub server..." | Apache is not running, or the folder is not inside `xampp\htdocs`. Open the site through `http://localhost/...`, not by double-clicking `index.html`. |
| "Cannot connect to the MySQL database..." | Start MySQL in XAMPP, import `schema.sql`, run `setup.php`, and check `DB_PASS` in `config.php`. |
| "Server error. ..." with details | Confirm `setup.php` completed and check the PHP error log. Keep `PH_DEBUG` off on a public site. |
| The page looks old after an update | Press **Ctrl + Shift + R**. |
| "The QR image could not be saved" | Make sure the `payments` folder is not read-only. |
| The GCash QR shows "SAMPLE" | Upload your real QR in Dashboard > Payments. |

Documentation of the changes: `REVISIONS.md`. Duplicate-order check (older versions): `check-duplicates.sql`.
