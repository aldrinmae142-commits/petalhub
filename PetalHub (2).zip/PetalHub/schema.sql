CREATE DATABASE IF NOT EXISTS petalhub CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE petalhub;

-- ============ ACCOUNTS ============
CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  fname VARCHAR(40) NOT NULL,
  mname VARCHAR(40) NULL DEFAULT NULL,
  lname VARCHAR(40) NOT NULL DEFAULT '',
  email VARCHAR(200) NOT NULL UNIQUE,
  salt CHAR(32) NOT NULL,
  password_hash CHAR(128) NOT NULL,
  role ENUM('customer','admin') NOT NULL DEFAULT 'customer',
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS sessions (
  token_hash CHAR(64) PRIMARY KEY,
  user_id INT NOT NULL,
  expires_at DATETIME NOT NULL,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS password_reset_codes (
  user_id INT PRIMARY KEY,
  code_hash VARCHAR(255) NOT NULL,
  expires_at DATETIME NOT NULL,
  attempts TINYINT UNSIGNED NOT NULL DEFAULT 0,
  requested_at DATETIME NOT NULL,
  reset_token_hash CHAR(64) NULL,
  reset_expires_at DATETIME NULL,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  INDEX idx_password_reset_expires_at (expires_at)
);

-- A customer's reusable addresses; each address is stored in its own row.
CREATE TABLE IF NOT EXISTS addresses (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  street VARCHAR(200) NOT NULL,
  city VARCHAR(100) NOT NULL,
  zip VARCHAR(20) NOT NULL DEFAULT '',
  contact_phone VARCHAR(30) NOT NULL DEFAULT '',
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ============ CATALOG ============
CREATE TABLE IF NOT EXISTS products (
  id INT PRIMARY KEY,
  name VARCHAR(80) NOT NULL,
  price DECIMAL(10,2) NOT NULL,
  qty INT NOT NULL,
  sold INT NOT NULL DEFAULT 0,               -- number of stems sold (cancelled orders are taken back out)
  unit VARCHAR(40) NOT NULL,
  description VARCHAR(300) NOT NULL DEFAULT '',
  image_path VARCHAR(255) NOT NULL DEFAULT '',
  active TINYINT(1) NOT NULL DEFAULT 1,
  available TINYINT(1) NOT NULL DEFAULT 1,   -- the admin sets In stock (1) / Out of stock (0)
  UNIQUE KEY uq_products_name (name)
);

CREATE TABLE IF NOT EXISTS petalhub_settings (
  setting_key VARCHAR(40) PRIMARY KEY,
  setting_value VARCHAR(100) NOT NULL
);

INSERT IGNORE INTO petalhub_settings (setting_key, setting_value) VALUES
  ('weather', ''),
  ('gcash_name', 'PetalHub Flower Shop'),
  ('gcash_number', ''),
  ('gcash_qr', 'payments/gcash-qr.png');

INSERT IGNORE INTO products (id, name, price, qty, unit, description, image_path) VALUES
  (1, 'White Roses', 18.00, 24, 'bunches available', 'Full, ruffled ivory-white blooms with softly blushed centers — a graceful classic, sold by the bunch of six stems.', 'flowers/whiteroses.jpg'),
  (2, 'Tulip',       12.00, 40, 'bunches available', 'Clean, cup-shaped blooms just opening, prized for their simple, elegant silhouette.', 'flowers/tulips.jpg'),
  (3, 'Sunflower',    9.00, 30, 'bunches available', 'Bold, sun-facing blooms with a deep centre — an instant lift for any room.', 'flowers/Sunflowers.jpg'),
  (4, 'Peony',       22.00, 12, 'bunches available', 'Lush, layered petals with a soft scent — a favourite for spring arrangements.', 'flowers/Peonies.jpg'),
  (5, 'Orchid',      28.00, 15, 'pots available', 'Elegant, long-lasting blooms with a sculptural, architectural form.', 'flowers/orchids_.jpg'),
  (6, 'Lily',        16.00, 20, 'bunches available', 'Trumpet-shaped blooms with a heady scent — striking in tall arrangements.', 'flowers/lily.jpg'),
  (7, 'Red Roses',   32.00, 18, 'bunches available', 'A hand-tied dozen of velvety red roses, chosen for their rich color and lasting impression.', 'flowers/red rose.jpg'),
  (8, 'Carnation',   14.00, 26, 'bunches available', 'Softly ruffled stems with a gentle, clove-like scent and a long vase life.', 'flowers/carnations.jpg'),
  (9, 'Chrysanthemum', 18.00, 22, 'bunches available', 'A generous spray of layered blooms that brings lasting color to any arrangement.', 'flowers/Chrysanthemums.jpg'),
  (10, 'Gladiolus',  20.00, 14, 'bunches available', 'Tall, elegant flower spikes that add graceful height and color to a bouquet.', 'flowers/gladiolus.jpg');

-- ============ RECOMMENDATIONS (many-to-many through junction tables) ============
CREATE TABLE IF NOT EXISTS events (
  event_id VARCHAR(40) PRIMARY KEY,
  name VARCHAR(60) NOT NULL
);

CREATE TABLE IF NOT EXISTS event_products (            -- junction: events <-> products
  id INT AUTO_INCREMENT PRIMARY KEY,
  event_id VARCHAR(40) NOT NULL,
  product_id INT NOT NULL,
  UNIQUE KEY uq_event_product (event_id, product_id),
  FOREIGN KEY (event_id) REFERENCES events(event_id) ON DELETE CASCADE,
  FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS weathers (
  weather_id VARCHAR(20) PRIMARY KEY,
  name VARCHAR(40) NOT NULL
);

CREATE TABLE IF NOT EXISTS weather_products (          -- junction: weathers <-> products
  id INT AUTO_INCREMENT PRIMARY KEY,
  weather_id VARCHAR(20) NOT NULL,
  product_id INT NOT NULL,
  UNIQUE KEY uq_weather_product (weather_id, product_id),
  FOREIGN KEY (weather_id) REFERENCES weathers(weather_id) ON DELETE CASCADE,
  FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
);

INSERT IGNORE INTO events (event_id, name) VALUES
  ('valentines', 'Valentine''s Day'),
  ('christmas', 'Christmas'),
  ('newyear', 'New Year''s Day'),
  ('mothersday', 'Mother''s Day'),
  ('halloween', 'Halloween');

INSERT IGNORE INTO event_products (event_id, product_id) VALUES
  ('valentines', 1), ('valentines', 2), ('valentines', 4),
  ('christmas', 3), ('christmas', 5), ('christmas', 6),
  ('newyear', 1), ('newyear', 3), ('newyear', 6),
  ('mothersday', 1), ('mothersday', 4), ('mothersday', 6),
  ('halloween', 8), ('halloween', 9), ('halloween', 10);

INSERT IGNORE INTO weathers (weather_id, name) VALUES
  ('sunny', 'Sunny'),
  ('rainy', 'Rainy');

INSERT IGNORE INTO weather_products (weather_id, product_id) VALUES
  ('sunny', 3), ('sunny', 2), ('sunny', 1),
  ('rainy', 5), ('rainy', 6), ('rainy', 4);

-- ============ DELIVERY ============
CREATE TABLE IF NOT EXISTS delivery_riders (
  id INT AUTO_INCREMENT PRIMARY KEY,
  fname VARCHAR(40) NOT NULL,
  mname VARCHAR(40) NULL DEFAULT NULL,
  lname VARCHAR(40) NOT NULL DEFAULT '',
  phone VARCHAR(30) NOT NULL,
  active TINYINT(1) NOT NULL DEFAULT 1,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_riders_name (fname, mname, lname)
);

INSERT IGNORE INTO delivery_riders (fname, mname, lname, phone) VALUES
  ('Alvin', 'Jay', 'Ornejo', '09123456789'),
  ('Ynzo', 'Martin', 'Pasaoa', '09123456788'),
  ('Aldrin', NULL, 'Magalang', '09696710101');

-- ============ ORDERS ============
CREATE TABLE IF NOT EXISTS orders (
  code VARCHAR(12) PRIMARY KEY,
  user_id INT NOT NULL,
  total DECIMAL(10,2) NOT NULL,
  fulfillment ENUM('pickup','delivery') NOT NULL,
  street VARCHAR(200) NOT NULL DEFAULT '',   -- delivery details are copied onto the order as a snapshot
  city VARCHAR(100) NOT NULL DEFAULT '',
  zip VARCHAR(20) NOT NULL DEFAULT '',
  customer_phone VARCHAR(30) NOT NULL DEFAULT '',
  rider_id INT NULL,                         -- assigned rider, with name and phone snapshots below
  rider_name VARCHAR(80) NOT NULL DEFAULT '',
  rider_phone VARCHAR(30) NOT NULL DEFAULT '',
  payment VARCHAR(40) NOT NULL,
  status ENUM('Pending','Preparing','Ready','Completed','Cancelled') NOT NULL DEFAULT 'Pending',
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  checkout_key VARCHAR(60) NULL,
  payment_status ENUM('not_required','awaiting','verified','rejected') NOT NULL DEFAULT 'not_required',   -- GCash QR payments
  gcash_ref VARCHAR(30) NULL,                                   -- 13-digit GCash reference number from the customer's receipt
  payment_proof VARCHAR(160) NOT NULL DEFAULT '',               -- optional screenshot, stored in payments/proofs
  payment_note VARCHAR(200) NOT NULL DEFAULT '',
  paid_at DATETIME NULL,
  UNIQUE KEY uq_orders_user_key (user_id, checkout_key),
  UNIQUE KEY uq_orders_gcash_ref (gcash_ref),
  FOREIGN KEY (user_id) REFERENCES users(id),
  FOREIGN KEY (rider_id) REFERENCES delivery_riders(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS order_items (
  id INT AUTO_INCREMENT PRIMARY KEY,
  order_code VARCHAR(12) NOT NULL,
  product_id INT NULL,
  name VARCHAR(80) NOT NULL,                 -- snapshot so history remains readable if a flower is removed or renamed
  qty INT NOT NULL,
  price DECIMAL(10,2) NOT NULL,              -- price per stem at the time of the order (so old orders never change)
  line_key VARCHAR(60) NULL,
  line_name VARCHAR(80) NOT NULL DEFAULT '',
  arrangement ENUM('single','bouquet','custom') NOT NULL DEFAULT 'single',
  line_qty INT NOT NULL DEFAULT 1,
  wrap_design VARCHAR(40) NULL,
  wrap_color VARCHAR(100) NOT NULL DEFAULT '',
  wrap_notes VARCHAR(300) NOT NULL DEFAULT '',
  wrap_fee DECIMAL(10,2) NOT NULL DEFAULT 0,
  FOREIGN KEY (order_code) REFERENCES orders(code) ON DELETE CASCADE,
  FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE SET NULL
);
