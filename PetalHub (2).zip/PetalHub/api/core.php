<?php
if (!defined('PETALHUB_API_ENTRY')) { http_response_code(404); exit; }
require_once PETALHUB_ROOT . '/config.php';
if (!defined('PETALHUB_ORDER_EMAILS_ENABLED')) define('PETALHUB_ORDER_EMAILS_ENABLED', true);
date_default_timezone_set(PH_TIMEZONE);
ini_set('display_errors', '0');
header('Content-Type: application/json; charset=utf-8');
header('X-Content-Type-Options: nosniff');
header('Cache-Control: no-store');

class ApiError extends Exception {}
function fail($code, $msg){ throw new ApiError($msg, $code); }
function send($code, $obj){ http_response_code($code); echo json_encode($obj, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES); exit; }
function emptyObj(){ return new stdClass(); }

/* ---------- database ---------- */
function db(){
  static $pdo = null;
  if ($pdo) return $pdo;
  try {
    $pdo = new PDO('mysql:host=' . DB_HOST . ';port=' . DB_PORT . ';dbname=' . DB_NAME . ';charset=utf8mb4', DB_USER, DB_PASS, array(
      PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC, PDO::ATTR_EMULATE_PREPARES => false));
  } catch (PDOException $e) {
    error_log('PetalHub DB connect: ' . $e->getMessage());
    $driverCode = isset($e->errorInfo[1]) ? (int)$e->errorInfo[1] : 0;
    if ($driverCode === 1045) fail(500, 'MySQL rejected the configured credentials. Check DB_HOST, DB_PORT, DB_USER and DB_PASS in config.php.');
    if ($driverCode === 1049) fail(500, 'The petalhub database does not exist. Import schema.sql in phpMyAdmin, then check config.php.');
    fail(500, 'Cannot connect to the MySQL database. In XAMPP start MySQL, import schema.sql in phpMyAdmin, and check config.php.');
  }
  $pdo->exec("SET time_zone = '" . date('P') . "'"); // keep MySQL NOW() and PHP on the same clock
  return $pdo;
}
function q($sql, $args = array()){ $st = db()->prepare($sql); $st->execute($args); return $st; }
function rows($sql, $args = array()){ return q($sql, $args)->fetchAll(); }
function row($sql, $args = array()){ $r = q($sql, $args)->fetch(); return $r ? $r : null; }
function marks($n){ return implode(',', array_fill(0, $n, '?')); }

/* ---------- small helpers ---------- */
function body($max = 100000){
  $raw = file_get_contents('php://input');
  if (strlen($raw) > $max) fail(413, 'That upload is too large. Please choose a smaller image.');
  if ($raw === '' || $raw === false) return array();
  $j = json_decode($raw, true);
  if (!is_array($j)) fail(400, 'Invalid JSON.');
  return $j;
}
function cut($s, $n){ return function_exists('mb_substr') ? mb_substr($s, 0, $n, 'UTF-8') : substr($s, 0, $n); }
function lower($s){ return function_exists('mb_strtolower') ? mb_strtolower($s, 'UTF-8') : strtolower($s); }
function str($v, $n){ return is_string($v) ? cut(trim($v), $n) : ''; }
function isInt($v){ return is_int($v) || (is_float($v) && floor($v) == $v); }
function isNum($v){ return is_int($v) || is_float($v); }
function get($a, $k, $d = null){ return is_array($a) && array_key_exists($k, $a) ? $a[$k] : $d; }
function iso($dt){ return gmdate('Y-m-d\TH:i:s', strtotime($dt)) . '.000Z'; }

/* ---------- passwords ---------- */
// New hashes are PBKDF2 ("p2:..."). Accounts made by the old Node version used scrypt; those still work when PHP's sodium
// extension is available, and are upgraded to PBKDF2 the first time the person logs in.
function hashPw($pw, $salt){ return 'p2:' . hash_pbkdf2('sha256', $pw, $salt, 120000, 64, false); }
function checkHash($stored, $pw, $salt){
  if ($stored === null || $stored === '') return false;
  if (isset($stored[0]) && $stored[0] === '$') return password_verify($pw, $stored);
  if (substr($stored, 0, 3) === 'p2:') return hash_equals($stored, hashPw($pw, $salt));
  if (function_exists('sodium_crypto_pwhash_scryptsalsa208sha256') && strlen($salt) === 32){
    try { return hash_equals($stored, bin2hex(sodium_crypto_pwhash_scryptsalsa208sha256(64, $pw, $salt, 524288, 16777216))); } catch (Exception $e) { return false; }
  }
  return false;
}
function newSalt(){ return bin2hex(random_bytes(16)); }
function displayName($person){
  return trim(implode(' ', array_filter(array(
    isset($person['fname']) ? trim((string)$person['fname']) : '',
    isset($person['mname']) ? trim((string)$person['mname']) : '',
    isset($person['lname']) ? trim((string)$person['lname']) : ''
  ), function($part){ return $part !== ''; })));
}
function hasColumn($table, $column){
  return (bool)row('SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = ?', array($table, $column));
}
function personNameParts($input, $maxPart = 40){
  if (is_array($input) && (array_key_exists('fname', $input) || array_key_exists('mname', $input) || array_key_exists('lname', $input))){
    $fname = str(get($input, 'fname'), $maxPart);
    $mname = str(get($input, 'mname'), $maxPart);
    $lname = str(get($input, 'lname'), $maxPart);
  } else {
    if (is_array($input)) $input = get($input, 'name', '');
    $parts = preg_split('/\s+/', trim((string)$input), -1, PREG_SPLIT_NO_EMPTY);
    $fname = isset($parts[0]) ? cut($parts[0], $maxPart) : '';
    $lname = isset($parts[1]) ? cut(array_pop($parts), $maxPart) : '';
    $mname = count($parts) > 1 ? cut(implode(' ', array_slice($parts, 1)), $maxPart) : '';
  }
  return array('fname' => $fname, 'mname' => $mname !== '' ? $mname : null, 'lname' => $lname);
}
function addUser($name, $email, $pw, $role){
  $salt = newSalt();
  if (hasColumn('users', 'name')){
    q('INSERT INTO users (name, fname, mname, lname, email, salt, password_hash, role) VALUES (?,?,?,?,?,?,?,?)',
      array(displayName($name), $name['fname'], $name['mname'], $name['lname'], $email, $salt, hashPw($pw, $salt), $role));
  } else {
    q('INSERT INTO users (fname, mname, lname, email, salt, password_hash, role) VALUES (?,?,?,?,?,?,?)',
      array($name['fname'], $name['mname'], $name['lname'], $email, $salt, hashPw($pw, $salt), $role));
  }
  return (int)db()->lastInsertId();
}

function seedDeliveryRiders(){
  $lock = row("SELECT GET_LOCK('petalhub_seed_riders', 30) AS l");
  if (!$lock || (int)$lock['l'] !== 1) fail(503, 'Could not initialize delivery riders. Please try again.');
  try {
    $seeds = array(
      array('Alvin', 'Jay', 'Ornejo', '09123456789'),
      array('Ynzo', 'Martin', 'Pasaoa', '09123456788'),
      array('Aldrin', null, 'Magalang', '09696710101')
    );
    $existingPhones = array_map(function($rider){ return preg_replace('/\\D/', '', $rider['phone']); }, rows('SELECT phone FROM delivery_riders'));
    foreach ($seeds as $rider){
      if (in_array($rider[3], $existingPhones, true)) continue;
      if (hasColumn('delivery_riders', 'name')){
        q('INSERT INTO delivery_riders (name, fname, mname, lname, phone) VALUES (?, ?, ?, ?, ?)',
          array(trim($rider[0] . ' ' . ($rider[1] !== null ? $rider[1] . ' ' : '') . $rider[2]), $rider[0], $rider[1], $rider[2], $rider[3]));
      } else {
        q('INSERT INTO delivery_riders (fname, mname, lname, phone) VALUES (?, ?, ?, ?)', $rider);
      }
      $existingPhones[] = $rider[3];
    }
  } finally {
    q("SELECT RELEASE_LOCK('petalhub_seed_riders')");
  }
}

/* ---------- GCash payment helpers (QR code, proof of payment) ---------- */
function paymentDir($sub = ''){
  $d = PETALHUB_ROOT . '/payments' . ($sub !== '' ? '/' . $sub : '');
  if (!is_dir($d)) @mkdir($d, 0775, true);
  return $d;
}
// uploaded files can never be run as PHP, and payment proofs can never be opened by a direct link
function protectPaymentDirs(){
  $a = paymentDir(); $b = paymentDir('proofs');
  if (is_dir($a) && !is_file($a . '/.htaccess')) @file_put_contents($a . '/.htaccess', "<FilesMatch \"\\.(php|phtml|phar)$\">\n  Require all denied\n</FilesMatch>\n");
  if (is_dir($b) && !is_file($b . '/.htaccess')) @file_put_contents($b . '/.htaccess', "Require all denied\n");
}
function decodeImage($dataUrl, $maxBytes){
  if (!is_string($dataUrl) || !preg_match('#^data:image/(png|jpeg|webp);base64,([A-Za-z0-9+/=\r\n]+)$#', $dataUrl, $m)) fail(400, 'Please upload a PNG, JPG or WebP image.');
  $bin = base64_decode($m[2], true);
  if ($bin === false || strlen($bin) < 100) fail(400, 'That image could not be read.');
  if (strlen($bin) > $maxBytes) fail(400, 'That image is too large. Please choose one under ' . round($maxBytes / 1000000, 1) . ' MB.');
  $info = @getimagesizefromstring($bin);
  $types = array(IMAGETYPE_PNG => 'png', IMAGETYPE_JPEG => 'jpg');
  if (defined('IMAGETYPE_WEBP')) $types[IMAGETYPE_WEBP] = 'webp';
  if (!$info || !isset($types[$info[2]])) fail(400, 'That file is not a valid image.');
  return array('bin' => $bin, 'ext' => $types[$info[2]], 'mime' => $info['mime']);
}
function paymentSettings(){
  $o = array('gcash_name' => 'PetalHub Flower Shop', 'gcash_number' => '', 'gcash_qr' => 'payments/gcash-qr.png');
  foreach (rows("SELECT setting_key, setting_value FROM petalhub_settings WHERE setting_key IN ('gcash_name','gcash_number','gcash_qr')") as $r) $o[$r['setting_key']] = $r['setting_value'];
  $file = PETALHUB_ROOT . '/' . $o['gcash_qr'];
  if (!is_file($file)){ $o['gcash_qr'] = 'payments/gcash-qr.png'; $file = PETALHUB_ROOT . '/payments/gcash-qr.png'; }
  return array('name' => $o['gcash_name'], 'number' => $o['gcash_number'], 'qr' => $o['gcash_qr'] . (is_file($file) ? '?v=' . filemtime($file) : ''), 'hasQr' => is_file($file));
}
function merchandisingData(){
  $out = array('weather' => '', 'eventFlowers' => array(), 'weatherFlowers' => array());
  $weather = row("SELECT setting_value FROM petalhub_settings WHERE setting_key = 'weather'");
  if ($weather && in_array($weather['setting_value'], array('sunny', 'rainy'), true)) $out['weather'] = $weather['setting_value'];
  foreach (rows('SELECT event_id FROM events') as $event) $out['eventFlowers'][$event['event_id']] = array();
  foreach (rows('SELECT weather_id FROM weathers') as $item) $out['weatherFlowers'][$item['weather_id']] = array();
  foreach (rows('SELECT event_id, product_id FROM event_products ORDER BY id') as $item)
    $out['eventFlowers'][$item['event_id']][] = (int)$item['product_id'];
  foreach (rows('SELECT weather_id, product_id FROM weather_products ORDER BY id') as $item)
    $out['weatherFlowers'][$item['weather_id']][] = (int)$item['product_id'];
  return $out;
}
// put the stems of a cancelled order back on the shelf (and put a flower that sold out back on sale)
function returnStock($code){
  $stockJoin = 'JOIN (SELECT product_id, SUM(qty) AS returned FROM order_items WHERE order_code = ? AND product_id IS NOT NULL GROUP BY product_id) i ON i.product_id = p.id';
  q('UPDATE products p ' . $stockJoin . ' SET p.available = IF(p.qty = 0, 1, p.available)', array($code));
  q('UPDATE products p ' . $stockJoin . ' SET p.qty = p.qty + i.returned', array($code));
}

/* ---------- first-run setup (adds missing columns, creates the admin account) ---------- */
function seedCatalogDefaults(){
  q("UPDATE products SET
    image_path = IF(image_path = '', CASE id
      WHEN 1 THEN 'flowers/whiteroses.jpg' WHEN 2 THEN 'flowers/tulips.jpg'
      WHEN 3 THEN 'flowers/Sunflowers.jpg' WHEN 4 THEN 'flowers/Peonies.jpg'
      WHEN 5 THEN 'flowers/orchids_.jpg' WHEN 6 THEN 'flowers/lily.jpg'
      WHEN 7 THEN 'flowers/red rose.jpg' WHEN 8 THEN 'flowers/carnations.jpg'
      WHEN 9 THEN 'flowers/Chrysanthemums.jpg' WHEN 10 THEN 'flowers/gladiolus.jpg'
      ELSE image_path END, image_path),
    description = IF(description = '', CASE id
      WHEN 1 THEN 'Full, ruffled ivory-white blooms with softly blushed centers — a graceful classic, sold by the bunch of six stems.'
      WHEN 2 THEN 'Clean, cup-shaped blooms just opening, prized for their simple, elegant silhouette.'
      WHEN 3 THEN 'Bold, sun-facing blooms with a deep centre — an instant lift for any room.'
      WHEN 4 THEN 'Lush, layered petals with a soft scent — a favourite for spring arrangements.'
      WHEN 5 THEN 'Elegant, long-lasting blooms with a sculptural, architectural form.'
      WHEN 6 THEN 'Trumpet-shaped blooms with a heady scent — striking in tall arrangements.'
      WHEN 7 THEN 'A hand-tied dozen of velvety red roses, chosen for their rich color and lasting impression.'
      WHEN 8 THEN 'Softly ruffled stems with a gentle, clove-like scent and a long vase life.'
      WHEN 9 THEN 'A generous spray of layered blooms that brings lasting color to any arrangement.'
      WHEN 10 THEN 'Tall, elegant flower spikes that add graceful height and color to a bouquet.'
      ELSE description END, description)
    WHERE id BETWEEN 1 AND 10 AND (image_path = '' OR description = '')");
}
function ensureAdmin(){
  if (row("SELECT id FROM users WHERE role = 'admin' LIMIT 1")) return;
  if (!defined('ADMIN_EMAIL') || !defined('ADMIN_PASSWORD')) return;
  try {
    addUser(personNameParts('Admin'), strtolower(ADMIN_EMAIL), ADMIN_PASSWORD, 'admin');
  } catch (PDOException $e){
    if (!isset($e->errorInfo[1]) || (int)$e->errorInfo[1] !== 1062) throw $e;
  }
}
function ensureSetup(){
  // an admin made by the old Node version can only be read when PHP has the sodium extension; otherwise reset it to config.php's password
  if (!function_exists('sodium_crypto_pwhash_scryptsalsa208sha256')){ $sl = newSalt(); q("UPDATE users SET salt = ?, password_hash = ? WHERE role = 'admin' AND password_hash NOT LIKE 'p2:%' AND password_hash NOT LIKE '$%'", array($sl, hashPw(ADMIN_PASSWORD, $sl))); }
  $check = "SELECT (SELECT COUNT(*) FROM users WHERE role = 'admin') AS a,
                   (SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'addresses') AS addresses_table,
                   (SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'password_reset_codes') AS reset_table,
                   (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'password_reset_codes' AND COLUMN_NAME IN ('reset_token_hash','reset_expires_at')) AS reset_fields,
                   (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'users' AND COLUMN_NAME IN ('fname','mname','lname')) AS user_name_fields,
                   (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'delivery_riders' AND COLUMN_NAME IN ('fname','mname','lname')) AS rider_name_fields,
                   (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'users' AND COLUMN_NAME = 'mname' AND IS_NULLABLE = 'YES') AS user_mname_nullable,
                   (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'delivery_riders' AND COLUMN_NAME = 'mname' AND IS_NULLABLE = 'YES') AS rider_mname_nullable,
                   (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'users' AND COLUMN_NAME = 'name') AS legacy_user_name,
                   (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'delivery_riders' AND COLUMN_NAME = 'name') AS legacy_rider_name,
                   (SELECT COUNT(*) FROM information_schema.STATISTICS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'orders' AND INDEX_NAME = 'uq_orders_user_key') AS k,
                   (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'order_items' AND COLUMN_NAME IN ('name','line_key','line_name','arrangement','line_qty','wrap_design','wrap_color','wrap_notes','wrap_fee')) AS i,
                   (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'order_items' AND COLUMN_NAME = 'product_id' AND IS_NULLABLE = 'YES') AS product_nullable,
                   (SELECT COUNT(*) FROM information_schema.KEY_COLUMN_USAGE k JOIN information_schema.REFERENTIAL_CONSTRAINTS r ON r.CONSTRAINT_SCHEMA = k.CONSTRAINT_SCHEMA AND r.TABLE_NAME = k.TABLE_NAME AND r.CONSTRAINT_NAME = k.CONSTRAINT_NAME WHERE k.CONSTRAINT_SCHEMA = DATABASE() AND k.TABLE_NAME = 'order_items' AND k.COLUMN_NAME = 'product_id' AND k.REFERENCED_TABLE_NAME = 'products' AND r.DELETE_RULE = 'SET NULL') AS product_set_null,
                   (SELECT COUNT(*) FROM products WHERE id = 1 AND name = 'Garden Rose') AS legacy_product_name,
                   (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'products' AND COLUMN_NAME = 'available') AS av,
                   (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'products' AND COLUMN_NAME = 'image_path') AS img,
                   (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'products' AND COLUMN_NAME = 'description') AS product_description,
                   (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'orders' AND COLUMN_NAME IN ('street','city','zip','customer_phone','rider_id')) AS delivery_fields,
                   (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'orders' AND COLUMN_NAME IN ('subtotal','delivery_fee')) AS order_amount_fields,
                   (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'orders' AND COLUMN_NAME IN ('rider_name','rider_phone')) AS rider_snapshot_fields,
                   (SELECT COUNT(*) FROM information_schema.KEY_COLUMN_USAGE k JOIN information_schema.REFERENTIAL_CONSTRAINTS r ON r.CONSTRAINT_SCHEMA = k.CONSTRAINT_SCHEMA AND r.TABLE_NAME = k.TABLE_NAME AND r.CONSTRAINT_NAME = k.CONSTRAINT_NAME WHERE k.CONSTRAINT_SCHEMA = DATABASE() AND k.TABLE_NAME = 'orders' AND k.COLUMN_NAME = 'rider_id' AND k.REFERENCED_TABLE_NAME = 'delivery_riders' AND r.DELETE_RULE IN ('RESTRICT','NO ACTION')) AS rider_restrict_fk,
                   (SELECT COUNT(*) FROM information_schema.STATISTICS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'delivery_riders' AND INDEX_NAME = 'uq_riders_name') AS rider_name_unique,
                   (SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'delivery_riders') AS riders_table,
                   (SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME IN ('petalhub_settings','events','event_products','weathers','weather_products')) AS merchandising_tables,
                   (SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'event_products') AS event_products_table,
                   (SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'weather_products') AS weather_products_table,
                   (SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'event_flowers') AS legacy_event_table,
                   (SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'weather_flowers') AS legacy_weather_table,
                   (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'orders' AND COLUMN_NAME IN ('payment_status','gcash_ref','payment_proof','payment_note','paid_at')) AS pay_fields,
                   (SELECT COUNT(*) FROM information_schema.STATISTICS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'orders' AND INDEX_NAME = 'uq_orders_gcash_ref') AS gk,
                   (SELECT COUNT(*) FROM information_schema.STATISTICS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'orders' AND INDEX_NAME = 'idx_orders_user_created') AS ou,
                   (SELECT COUNT(*) FROM information_schema.STATISTICS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'orders' AND INDEX_NAME = 'idx_orders_created_code') AS oc,
                   (SELECT COUNT(*) FROM information_schema.STATISTICS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'orders' AND INDEX_NAME = 'idx_orders_rider_id') AS ri,
                   (SELECT COUNT(*) FROM information_schema.STATISTICS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sessions' AND INDEX_NAME = 'idx_sessions_expires_at') AS se,
                   (SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'cart_items') AS cart_table";
  $ready = function($s){ return $s['a'] > 0 && $s['addresses_table'] == 1 && $s['reset_table'] == 1 && $s['reset_fields'] == 2 && $s['user_name_fields'] == 3 && $s['rider_name_fields'] == 3 && $s['user_mname_nullable'] == 1 && $s['rider_mname_nullable'] == 1 && $s['k'] > 0 && $s['i'] == 9 && $s['product_nullable'] == 1 && $s['product_set_null'] > 0 && $s['legacy_product_name'] == 0 && $s['av'] > 0 && $s['img'] > 0 && $s['product_description'] > 0 && $s['delivery_fields'] == 5 && $s['order_amount_fields'] == 2 && $s['rider_snapshot_fields'] == 0 && $s['rider_restrict_fk'] > 0 && $s['rider_name_unique'] == 0 && $s['riders_table'] == 1 && $s['merchandising_tables'] == 5 && $s['pay_fields'] == 5 && $s['gk'] > 0 && $s['ou'] > 0 && $s['oc'] > 0 && $s['ri'] > 0 && $s['se'] > 0 && $s['cart_table'] == 1; };
  $s = row($check);
  if ((int)$s['product_description']) seedCatalogDefaults();
  if ($ready($s)){
    q("INSERT IGNORE INTO petalhub_settings (setting_key, setting_value) VALUES ('weather',''), ('gcash_name','PetalHub Flower Shop'), ('gcash_number',''), ('gcash_qr','payments/gcash-qr.png')");
    q("UPDATE products SET image_path = 'flowers/whiteroses.jpg' WHERE image_path = 'flowers/White roses.jpg'");
    return;
  }
  // Several requests can arrive at the same moment on the very first page load: only one of them may run the setup.
  $lock = row("SELECT GET_LOCK('petalhub_setup', 30) AS l");
  if (!$lock || (int)$lock['l'] !== 1) fail(503, 'Could not initialize the database. Please run setup again.');
  try {
    $s = row($check); // look again now that we hold the lock; another request may have finished the setup already
    if ($ready($s)){
      q("INSERT IGNORE INTO petalhub_settings (setting_key, setting_value) VALUES ('weather','')");
      q("UPDATE products SET image_path = 'flowers/whiteroses.jpg' WHERE image_path = 'flowers/White roses.jpg'");
      return;
    }
    $seedRiders = !(int)$s['riders_table'];
    $seedEventProducts = !(int)$s['event_products_table'];
    $seedWeatherProducts = !(int)$s['weather_products_table'];
    $migrateLegacyEvents = $seedEventProducts && (int)$s['legacy_event_table'];
    $migrateLegacyWeather = $seedWeatherProducts && (int)$s['legacy_weather_table'];
    q("CREATE TABLE IF NOT EXISTS addresses (
      id INT AUTO_INCREMENT PRIMARY KEY,
      user_id INT NOT NULL,
      street VARCHAR(200) NOT NULL,
      city VARCHAR(100) NOT NULL,
      zip VARCHAR(20) NOT NULL DEFAULT '',
      contact_phone VARCHAR(30) NOT NULL DEFAULT '',
      created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
      KEY idx_addresses_user (user_id, id),
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    )");
    q("CREATE TABLE IF NOT EXISTS petalhub_settings (setting_key VARCHAR(40) PRIMARY KEY, setting_value VARCHAR(100) NOT NULL)");
    q("CREATE TABLE IF NOT EXISTS password_reset_codes (
      user_id INT PRIMARY KEY,
      code_hash VARCHAR(255) NOT NULL,
      expires_at DATETIME NOT NULL,
      attempts TINYINT UNSIGNED NOT NULL DEFAULT 0,
      requested_at DATETIME NOT NULL,
      reset_token_hash CHAR(64) NULL,
      reset_expires_at DATETIME NULL,
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
      INDEX idx_password_reset_expires_at (expires_at)
    )");
    q("CREATE TABLE IF NOT EXISTS events (event_id VARCHAR(40) PRIMARY KEY, name VARCHAR(60) NOT NULL)");
    q("CREATE TABLE IF NOT EXISTS event_products (
      id INT AUTO_INCREMENT PRIMARY KEY,
      event_id VARCHAR(40) NOT NULL,
      product_id INT NOT NULL,
      UNIQUE KEY uq_event_product (event_id, product_id),
      FOREIGN KEY (event_id) REFERENCES events(event_id) ON DELETE CASCADE,
      FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
    )");
    q("CREATE TABLE IF NOT EXISTS weathers (weather_id VARCHAR(20) PRIMARY KEY, name VARCHAR(40) NOT NULL)");
    q("CREATE TABLE IF NOT EXISTS weather_products (
      id INT AUTO_INCREMENT PRIMARY KEY,
      weather_id VARCHAR(20) NOT NULL,
      product_id INT NOT NULL,
      UNIQUE KEY uq_weather_product (weather_id, product_id),
      FOREIGN KEY (weather_id) REFERENCES weathers(weather_id) ON DELETE CASCADE,
      FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
    )");
    q("CREATE TABLE IF NOT EXISTS cart_items (
      id INT AUTO_INCREMENT PRIMARY KEY,
      user_id INT NOT NULL,
      product_id INT NOT NULL,
      qty INT NOT NULL,
      line_key VARCHAR(60) NOT NULL,
      line_name VARCHAR(80) NOT NULL DEFAULT '',
      arrangement ENUM('single','bouquet','custom') NOT NULL DEFAULT 'single',
      line_qty INT NOT NULL DEFAULT 1,
      wrap_design VARCHAR(40) NULL,
      wrap_color VARCHAR(100) NOT NULL DEFAULT '',
      wrap_notes VARCHAR(300) NOT NULL DEFAULT '',
      UNIQUE KEY uq_cart_line_product (user_id, line_key, product_id),
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
      FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
    )");
    q("CREATE TABLE IF NOT EXISTS delivery_riders (
      id INT AUTO_INCREMENT PRIMARY KEY,
      fname VARCHAR(40) NOT NULL,
      mname VARCHAR(40) NULL DEFAULT NULL,
      lname VARCHAR(40) NOT NULL DEFAULT '',
      phone VARCHAR(30) NOT NULL,
      active TINYINT(1) NOT NULL DEFAULT 1,
      created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
    )");
    q("INSERT IGNORE INTO petalhub_settings (setting_key, setting_value) VALUES ('weather','')");
    q("INSERT IGNORE INTO events (event_id, name) VALUES
      ('valentines', 'Valentine''s Day'), ('christmas', 'Christmas'), ('newyear', 'New Year''s Day'),
      ('mothersday', 'Mother''s Day'), ('halloween', 'Halloween')");
    q("INSERT IGNORE INTO weathers (weather_id, name) VALUES ('sunny', 'Sunny'), ('rainy', 'Rainy')");
    if ($seedEventProducts) q("INSERT IGNORE INTO event_products (event_id, product_id)
        SELECT 'valentines', id FROM products WHERE id IN (1,2,4)
        UNION ALL SELECT 'christmas', id FROM products WHERE id IN (3,5,6)
        UNION ALL SELECT 'newyear', id FROM products WHERE id IN (1,3,6)
        UNION ALL SELECT 'mothersday', id FROM products WHERE id IN (1,4,6)
        UNION ALL SELECT 'halloween', id FROM products WHERE id IN (8,9,10)");
    if ($seedWeatherProducts) q("INSERT IGNORE INTO weather_products (weather_id, product_id)
        SELECT 'sunny', id FROM products WHERE id IN (3,2,1)
        UNION ALL SELECT 'rainy', id FROM products WHERE id IN (5,6,4)");
    $copyLegacy = function($source, $parentColumn, $junction, $junctionParent){
      foreach (rows('SELECT ' . $parentColumn . ' AS item_id, flower_ids FROM ' . $source) as $legacy){
        q('DELETE FROM ' . $junction . ' WHERE ' . $junctionParent . ' = ?', array($legacy['item_id']));
        $ids = array();
        foreach (explode(',', $legacy['flower_ids']) as $id){
          $id = trim($id);
          if (ctype_digit($id) && (int)$id > 0) $ids[(int)$id] = (int)$id;
        }
        if (!$ids) continue;
        $valid = rows('SELECT id FROM products WHERE id IN (' . marks(count($ids)) . ')', array_values($ids));
        foreach ($valid as $product) q('INSERT IGNORE INTO ' . $junction . ' (' . $junctionParent . ', product_id) VALUES (?, ?)', array($legacy['item_id'], $product['id']));
      }
    };
    if ($migrateLegacyEvents) $copyLegacy('event_flowers', 'event_id', 'event_products', 'event_id');
    if ($migrateLegacyWeather) $copyLegacy('weather_flowers', 'weather_id', 'weather_products', 'weather_id');
    $addCol = function($t, $c, $def){
      if (rows('SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = ?', array($t, $c))) return;
      try { q('ALTER TABLE ' . $t . ' ADD COLUMN ' . $c . ' ' . $def); }
      catch (PDOException $e) { if (!isset($e->errorInfo[1]) || $e->errorInfo[1] != 1060) throw $e; } // 1060 = column already exists
    };
    $addCol('users', 'fname', "VARCHAR(40) NOT NULL DEFAULT ''");
    $addCol('users', 'mname', 'VARCHAR(40) NULL DEFAULT NULL');
    $addCol('users', 'lname', "VARCHAR(40) NOT NULL DEFAULT ''");
    $addCol('delivery_riders', 'fname', "VARCHAR(40) NOT NULL DEFAULT ''");
    $addCol('delivery_riders', 'mname', 'VARCHAR(40) NULL DEFAULT NULL');
    $addCol('delivery_riders', 'lname', "VARCHAR(40) NOT NULL DEFAULT ''");
    $addCol('password_reset_codes', 'reset_token_hash', 'CHAR(64) NULL');
    $addCol('password_reset_codes', 'reset_expires_at', 'DATETIME NULL');
    if (!(int)$s['user_mname_nullable']) q('ALTER TABLE users MODIFY mname VARCHAR(40) NULL DEFAULT NULL');
    if (!(int)$s['rider_mname_nullable']) q('ALTER TABLE delivery_riders MODIFY mname VARCHAR(40) NULL DEFAULT NULL');
    if ((int)$s['legacy_user_name']) q("UPDATE users SET fname = LEFT(SUBSTRING_INDEX(TRIM(name), ' ', 1), 40), lname = LEFT(TRIM(SUBSTRING(TRIM(name), LENGTH(SUBSTRING_INDEX(TRIM(name), ' ', 1)) + 1)), 40) WHERE fname = ''");
    if ((int)$s['legacy_rider_name']) q("UPDATE delivery_riders SET fname = LEFT(SUBSTRING_INDEX(TRIM(name), ' ', 1), 40), lname = LEFT(TRIM(SUBSTRING(TRIM(name), LENGTH(SUBSTRING_INDEX(TRIM(name), ' ', 1)) + 1)), 40) WHERE fname = ''");
    $addCol('products', 'active', 'TINYINT(1) NOT NULL DEFAULT 1');
    $addCol('products', 'description', "VARCHAR(300) NOT NULL DEFAULT ''");
    $addCol('products', 'image_path', "VARCHAR(255) NOT NULL DEFAULT ''");
    seedCatalogDefaults();
    // the admin decides In stock / Out of stock; 1 = on sale, 0 = marked Out of stock (customers cannot add it to a cart)
    $addCol('products', 'available', 'TINYINT(1) NOT NULL DEFAULT 1');
    $addCol('order_items', 'name', "VARCHAR(80) NOT NULL DEFAULT ''");
    $addCol('order_items', 'line_key', 'VARCHAR(60) NULL');
    $addCol('order_items', 'line_name', "VARCHAR(80) NOT NULL DEFAULT ''");
    $addCol('order_items', 'arrangement', "ENUM('single','bouquet','custom') NOT NULL DEFAULT 'single'");
    $addCol('order_items', 'line_qty', 'INT NOT NULL DEFAULT 1');
    $addCol('order_items', 'wrap_design', 'VARCHAR(40) NULL');
    $addCol('order_items', 'wrap_color', "VARCHAR(100) NOT NULL DEFAULT ''");
    $addCol('order_items', 'wrap_notes', "VARCHAR(300) NOT NULL DEFAULT ''");
    $addCol('order_items', 'wrap_fee', 'DECIMAL(10,2) NOT NULL DEFAULT 0');
    $addCol('order_items', 'product_id', 'INT NULL');
    q("UPDATE order_items i JOIN products p ON p.id = i.product_id SET i.name = p.name WHERE i.name = ''");
    $productFks = rows("SELECT k.CONSTRAINT_NAME, r.DELETE_RULE FROM information_schema.KEY_COLUMN_USAGE k
      JOIN information_schema.REFERENTIAL_CONSTRAINTS r ON r.CONSTRAINT_SCHEMA = k.CONSTRAINT_SCHEMA AND r.TABLE_NAME = k.TABLE_NAME AND r.CONSTRAINT_NAME = k.CONSTRAINT_NAME
      WHERE k.CONSTRAINT_SCHEMA = DATABASE() AND k.TABLE_NAME = 'order_items' AND k.COLUMN_NAME = 'product_id' AND k.REFERENCED_TABLE_NAME = 'products'");
    $hasSetNullFk = false;
    foreach ($productFks as $fk) if ($fk['DELETE_RULE'] === 'SET NULL') $hasSetNullFk = true;
    if (!$hasSetNullFk || !(int)$s['product_nullable']){
      foreach ($productFks as $fk){
        if (!preg_match('/^[A-Za-z0-9_]+$/', $fk['CONSTRAINT_NAME'])) fail(500, 'Could not safely update the order item product constraint.');
        q('ALTER TABLE order_items DROP FOREIGN KEY `' . $fk['CONSTRAINT_NAME'] . '`');
      }
      q('ALTER TABLE order_items MODIFY product_id INT NULL');
      q('ALTER TABLE order_items ADD CONSTRAINT fk_order_items_product FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE SET NULL');
    }
    // every checkout carries a one-time key; the UNIQUE index makes it impossible to store the same checkout twice
    $addCol('orders', 'checkout_key', 'VARCHAR(60) NULL');
    $addCol('orders', 'street', "VARCHAR(200) NOT NULL DEFAULT ''");
    $addCol('orders', 'city', "VARCHAR(100) NOT NULL DEFAULT ''");
    $addCol('orders', 'zip', "VARCHAR(20) NOT NULL DEFAULT ''");
    $addCol('orders', 'customer_phone', "VARCHAR(30) NOT NULL DEFAULT ''");
    $addCol('orders', 'rider_id', 'INT NULL');
    // GCash QR payments: the customer submits the GCash reference number, the admin verifies it before the order moves forward
    $addCol('orders', 'payment_status', "VARCHAR(20) NOT NULL DEFAULT 'not_required'"); // not_required | awaiting | verified | rejected
    $addCol('orders', 'gcash_ref', 'VARCHAR(30) NULL');
    $addCol('orders', 'payment_proof', "VARCHAR(160) NOT NULL DEFAULT ''");
    $addCol('orders', 'payment_note', "VARCHAR(200) NOT NULL DEFAULT ''");
    $addCol('orders', 'paid_at', 'DATETIME NULL');
    $addCol('orders', 'subtotal', 'DECIMAL(10,2) NOT NULL DEFAULT 0');
    $addCol('orders', 'delivery_fee', 'DECIMAL(10,2) NOT NULL DEFAULT 0');
    $deliveryFee = petalhubDeliveryFee();
    q("UPDATE orders o
      LEFT JOIN (
        SELECT order_code, ROUND(SUM(qty * price + wrap_fee), 2) AS items_subtotal
        FROM order_items GROUP BY order_code
      ) i ON i.order_code = o.code
      SET o.delivery_fee = IF(o.fulfillment = 'delivery' AND ROUND(o.total - COALESCE(i.items_subtotal, 0), 2) = ?, ?, 0),
          o.subtotal = o.total - IF(o.fulfillment = 'delivery' AND ROUND(o.total - COALESCE(i.items_subtotal, 0), 2) = ?, ?, 0)
      WHERE o.subtotal = 0 AND o.delivery_fee = 0 AND o.total <> 0",
      array($deliveryFee, $deliveryFee, $deliveryFee, $deliveryFee));
    if (rows("SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'orders' AND COLUMN_NAME = 'address_id'")){
      q("UPDATE orders o JOIN addresses a ON a.id = o.address_id
        SET o.street = IF(o.street = '', a.street, o.street),
            o.city = IF(o.city = '', a.city, o.city),
            o.zip = IF(o.zip = '', a.zip, o.zip),
            o.customer_phone = IF(o.customer_phone = '', a.contact_phone, o.customer_phone)
        WHERE o.fulfillment = 'delivery' AND o.address_id IS NOT NULL");
    }
    $addIndex = function($table, $index, $definition){
      if (rows('SELECT 1 FROM information_schema.STATISTICS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND INDEX_NAME = ? LIMIT 1', array($table, $index))) return;
      q('ALTER TABLE ' . $table . ' ADD INDEX ' . $index . ' (' . $definition . ')');
    };
    $addIndex('orders', 'idx_orders_user_created', 'user_id, created_at, code');
    $addIndex('orders', 'idx_orders_created_code', 'created_at, code');
    $addIndex('orders', 'idx_orders_rider_id', 'rider_id');
    $addIndex('sessions', 'idx_sessions_expires_at', 'expires_at');
    if ((int)$s['rider_name_unique']) q('ALTER TABLE delivery_riders DROP INDEX uq_riders_name');
    if (hasColumn('orders', 'rider_name') && hasColumn('orders', 'rider_phone')){
      q('UPDATE orders o LEFT JOIN delivery_riders r ON r.id = o.rider_id SET o.rider_id = NULL WHERE o.rider_id IS NOT NULL AND r.id IS NULL');
      foreach (rows("SELECT code, rider_name, rider_phone FROM orders WHERE rider_id IS NULL AND rider_name <> ''") as $legacyAssignment){
        $rider = row("SELECT id FROM delivery_riders
          WHERE phone = ? AND CONCAT_WS(' ', NULLIF(fname, ''), NULLIF(mname, ''), NULLIF(lname, '')) = ?
          ORDER BY id LIMIT 1", array($legacyAssignment['rider_phone'], $legacyAssignment['rider_name']));
        if (!$rider){
          $name = personNameParts($legacyAssignment['rider_name']);
          q('INSERT INTO delivery_riders (fname, mname, lname, phone, active) VALUES (?, ?, ?, ?, 0)',
            array($name['fname'], $name['mname'], $name['lname'], $legacyAssignment['rider_phone']));
          $rider = array('id' => (int)db()->lastInsertId());
        }
        q('UPDATE orders SET rider_id = ? WHERE code = ?', array($rider['id'], $legacyAssignment['code']));
      }
    }
    if (hasColumn('orders', 'rider_name')) q('ALTER TABLE orders DROP COLUMN rider_name');
    if (hasColumn('orders', 'rider_phone')) q('ALTER TABLE orders DROP COLUMN rider_phone');
    $riderFks = rows("SELECT k.CONSTRAINT_NAME, r.DELETE_RULE FROM information_schema.KEY_COLUMN_USAGE k
      JOIN information_schema.REFERENTIAL_CONSTRAINTS r ON r.CONSTRAINT_SCHEMA = k.CONSTRAINT_SCHEMA AND r.TABLE_NAME = k.TABLE_NAME AND r.CONSTRAINT_NAME = k.CONSTRAINT_NAME
      WHERE k.CONSTRAINT_SCHEMA = DATABASE() AND k.TABLE_NAME = 'orders' AND k.COLUMN_NAME = 'rider_id' AND k.REFERENCED_TABLE_NAME = 'delivery_riders'");
    $hasRestrictRiderFk = false;
    foreach ($riderFks as $fk) if (in_array($fk['DELETE_RULE'], array('RESTRICT', 'NO ACTION'), true)) $hasRestrictRiderFk = true;
    if (!$hasRestrictRiderFk){
      foreach ($riderFks as $fk){
        if (!preg_match('/^[A-Za-z0-9_]+$/', $fk['CONSTRAINT_NAME'])) fail(500, 'Could not safely update the order rider constraint.');
        q('ALTER TABLE orders DROP FOREIGN KEY `' . $fk['CONSTRAINT_NAME'] . '`');
      }
      q('ALTER TABLE orders ADD CONSTRAINT fk_orders_rider FOREIGN KEY (rider_id) REFERENCES delivery_riders(id) ON DELETE RESTRICT');
    }
    try { q('ALTER TABLE orders ADD UNIQUE KEY uq_orders_gcash_ref (gcash_ref)'); }
    catch (PDOException $e) { if (!isset($e->errorInfo[1]) || $e->errorInfo[1] != 1061) throw $e; } // 1061 = key already exists
    q("INSERT IGNORE INTO petalhub_settings (setting_key, setting_value) VALUES ('gcash_name','PetalHub Flower Shop'), ('gcash_number',''), ('gcash_qr','payments/gcash-qr.png')");
    if (!$s['k']){
      try { q('ALTER TABLE orders ADD UNIQUE KEY uq_orders_user_key (user_id, checkout_key)'); }
      catch (PDOException $e) { if (!isset($e->errorInfo[1]) || $e->errorInfo[1] != 1061) throw $e; } // 1061 = key already exists
    }
    if (!$s['a']){
      try { addUser(personNameParts('Admin'), strtolower(ADMIN_EMAIL), ADMIN_PASSWORD, 'admin'); }
      catch (PDOException $e) { if (!isset($e->errorInfo[1]) || $e->errorInfo[1] != 1062) throw $e; } // 1062 = admin already exists
    }
    q("UPDATE products SET name = 'White Roses' WHERE id = 1 AND name = 'Garden Rose'");
    q("UPDATE products SET image_path = 'flowers/whiteroses.jpg' WHERE image_path = 'flowers/White roses.jpg'");
    if ($seedRiders) seedDeliveryRiders();
  } finally {
    q("SELECT RELEASE_LOCK('petalhub_setup')");
  }
}

/* ---------- login sessions ---------- */
function bearer(){
  if (!empty($_SERVER['HTTP_X_AUTH_TOKEN'])) return $_SERVER['HTTP_X_AUTH_TOKEN'];
  $a = isset($_SERVER['HTTP_AUTHORIZATION']) ? $_SERVER['HTTP_AUTHORIZATION'] : (isset($_SERVER['REDIRECT_HTTP_AUTHORIZATION']) ? $_SERVER['REDIRECT_HTTP_AUTHORIZATION'] : '');
  if ($a === '' && function_exists('getallheaders')) foreach (getallheaders() as $k => $v) if (strtolower($k) === 'authorization') $a = $v;
  return preg_match('/^Bearer (.+)$/', $a, $m) ? $m[1] : '';
}
function authUser(){
  $t = bearer(); if ($t === '') return null;
  return row("SELECT u.id, CONCAT_WS(' ', NULLIF(u.fname, ''), NULLIF(u.mname, ''), NULLIF(u.lname, '')) AS name, u.email, u.role
    FROM sessions s JOIN users u ON u.id = s.user_id WHERE s.token_hash = ? AND s.expires_at > NOW()", array(hash('sha256', $t)));
}
function startSession($u){
  $t = bin2hex(random_bytes(24));
  if (random_int(1, 64) === 1) q('DELETE FROM sessions WHERE expires_at < NOW() LIMIT 100');
  q('INSERT INTO sessions (token_hash, user_id, expires_at) VALUES (?, ?, DATE_ADD(NOW(), INTERVAL 7 DAY))', array(hash('sha256', $t), $u['id']));
  send(200, array('token' => $t, 'user' => array('name' => $u['name'], 'email' => $u['email'], 'role' => $u['role'])));
}
// at most 10 login / register attempts per visitor per 5 minutes
function throttled($scope = 'auth'){
  $f = sys_get_temp_dir() . '/petalhub_throttle_' . preg_replace('/[^a-z0-9_-]/i', '', $scope) . '_' . md5(isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : '0') . '.json';
  $fh = @fopen($f, 'c+'); if (!$fh) return false;
  flock($fh, LOCK_EX);
  $now = time(); $t = array('n' => 0, 'reset' => $now + 300);
  $d = json_decode((string)stream_get_contents($fh), true);
  if (is_array($d) && isset($d['reset']) && $d['reset'] > $now) $t = $d;
  $t['n']++;
  ftruncate($fh, 0); rewind($fh); fwrite($fh, json_encode($t));
  flock($fh, LOCK_UN); fclose($fh);
  return $t['n'] > 10;
}
function startResetSession(){
  if (session_status() === PHP_SESSION_ACTIVE) return;
  ini_set('session.use_strict_mode', '1');
  ini_set('session.use_only_cookies', '1');
  session_name('petalhub_reset');
  $secure = !empty($_SERVER['HTTPS']) && strtolower($_SERVER['HTTPS']) !== 'off';
  session_set_cookie_params(array('lifetime' => 0, 'path' => '/', 'secure' => $secure, 'httponly' => true, 'samesite' => 'Lax'));
  if (!session_start()) fail(500, 'Could not start a secure password reset session.');
}
function checkResetCsrf(){
  startResetSession();
  $sent = isset($_SERVER['HTTP_X_CSRF_TOKEN']) ? $_SERVER['HTTP_X_CSRF_TOKEN'] : '';
  if (!isset($_SESSION['reset_csrf']) || !is_string($sent) || !hash_equals($_SESSION['reset_csrf'], $sent))
    fail(403, 'Your reset session expired. Reload the page and try again.');
}
function passwordResetMailConfigured(){
  $mailerFiles = array(
    PETALHUB_ROOT . '/vendor/phpmailer/phpmailer/src/Exception.php',
    PETALHUB_ROOT . '/vendor/phpmailer/phpmailer/src/SMTP.php',
    PETALHUB_ROOT . '/vendor/phpmailer/phpmailer/src/PHPMailer.php'
  );
  if (!is_file(PETALHUB_ROOT . '/smtp-config.php')) return false;
  foreach ($mailerFiles as $file) if (!is_file($file)) return false;
  require_once PETALHUB_ROOT . '/smtp-config.php';
  return defined('BREVO_SMTP_HOST') && BREVO_SMTP_HOST !== ''
    && defined('BREVO_SMTP_PORT') && (int)BREVO_SMTP_PORT === 587
    && defined('BREVO_SMTP_USERNAME') && BREVO_SMTP_USERNAME !== ''
    && defined('BREVO_SMTP_PASSWORD') && BREVO_SMTP_PASSWORD !== ''
    && defined('BREVO_FROM_NAME') && BREVO_FROM_NAME !== ''
    && defined('BREVO_FROM_EMAIL') && filter_var(BREVO_FROM_EMAIL, FILTER_VALIDATE_EMAIL);
}
function sendPasswordResetEmail($email, $code){
  if (!passwordResetMailConfigured()) return false;
  require_once PETALHUB_ROOT . '/vendor/phpmailer/phpmailer/src/Exception.php';
  require_once PETALHUB_ROOT . '/vendor/phpmailer/phpmailer/src/SMTP.php';
  require_once PETALHUB_ROOT . '/vendor/phpmailer/phpmailer/src/PHPMailer.php';
  try {
    $mail = new PHPMailer\PHPMailer\PHPMailer(true);
    $mail->isSMTP();
    $mail->Host = BREVO_SMTP_HOST;
    $mail->SMTPAuth = true;
    $mail->Username = BREVO_SMTP_USERNAME;
    $mail->Password = BREVO_SMTP_PASSWORD;
    $mail->SMTPSecure = PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_STARTTLS;
    $mail->Port = BREVO_SMTP_PORT;
    $mail->Timeout = 15;
    $mail->SMTPDebug = 0;
    $mail->CharSet = PHPMailer\PHPMailer\PHPMailer::CHARSET_UTF8;
    $mail->setFrom(BREVO_FROM_EMAIL, BREVO_FROM_NAME);
    $mail->addAddress($email);
    $mail->isHTML(true);
    $mail->Subject = 'Your PetalHub password reset code';
    $safeCode = htmlspecialchars($code, ENT_QUOTES, 'UTF-8');
    $expiresAt = date('F j, Y g:i A T', time() + 600);
    $mail->Body = '<div style="font-family:Arial,sans-serif;max-width:520px;margin:0 auto;padding:32px;color:#382922;background:#fffcf5;border:1px solid #eadfd1;border-radius:16px">' .
      '<p style="color:#8b3d45;font-weight:bold;letter-spacing:2px">PETALHUB</p><h1 style="font-size:24px">Reset your password</h1>' .
      '<p>Enter this one-time code in PetalHub to reset your password:</p><p style="font-size:32px;font-weight:bold;letter-spacing:8px;color:#8b3d45">' . $safeCode . '</p>' .
      '<p>This code expires in 10 minutes, at <strong>' . htmlspecialchars($expiresAt, ENT_QUOTES, 'UTF-8') . '</strong>, and can only be used once. If you did not request a reset, you can ignore this email.</p></div>';
    $mail->AltBody = 'Your PetalHub password reset code is ' . $code . '. It expires in 10 minutes, at ' . $expiresAt . ', and can only be used once. If you did not request a reset, ignore this email.';
    $mail->send();
    return true;
  } catch (Throwable $e) {
    error_log('PetalHub password reset email delivery failed: ' . $e->getMessage());
    return false;
  }
}
function sendPetalHubEmail($email, $subject, $htmlBody, $textBody){
  if (!filter_var($email, FILTER_VALIDATE_EMAIL) || !passwordResetMailConfigured()) return false;
  require_once PETALHUB_ROOT . '/vendor/phpmailer/phpmailer/src/Exception.php';
  require_once PETALHUB_ROOT . '/vendor/phpmailer/phpmailer/src/SMTP.php';
  require_once PETALHUB_ROOT . '/vendor/phpmailer/phpmailer/src/PHPMailer.php';
  try {
    $mail = new PHPMailer\PHPMailer\PHPMailer(true);
    $mail->isSMTP();
    $mail->Host = BREVO_SMTP_HOST;
    $mail->SMTPAuth = true;
    $mail->Username = BREVO_SMTP_USERNAME;
    $mail->Password = BREVO_SMTP_PASSWORD;
    $mail->SMTPSecure = PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_STARTTLS;
    $mail->Port = BREVO_SMTP_PORT;
    $mail->Timeout = 15;
    $mail->SMTPDebug = 0;
    $mail->CharSet = PHPMailer\PHPMailer\PHPMailer::CHARSET_UTF8;
    $mail->setFrom(BREVO_FROM_EMAIL, BREVO_FROM_NAME);
    $mail->addAddress($email);
    $mail->isHTML(true);
    $mail->Subject = $subject;
    $mail->Body = $htmlBody;
    $mail->AltBody = $textBody;
    $mail->send();
    return true;
  } catch (Throwable $e) {
    error_log('PetalHub order email delivery failed.');
    return false;
  }
}
function petalhubMailEscape($value){ return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8'); }
function petalhubMailMoney($value){ return number_format((float)$value, 2, '.', ','); }
function petalhubDeliveryFee(){ return 50.00; }
function petalhubOrderMailData($code){
  try {
    $order = row("SELECT o.*, u.email,
        CONCAT_WS(' ', NULLIF(u.fname, ''), NULLIF(u.mname, ''), NULLIF(u.lname, '')) AS customer
      FROM orders o JOIN users u ON u.id = o.user_id WHERE o.code = ?", array($code));
    if (!$order) return null;
    $order['items'] = rows('SELECT name, qty, price, wrap_fee FROM order_items WHERE order_code = ? ORDER BY id', array($code));
    return $order;
  } catch (PDOException $e) {
    error_log('PetalHub order email data could not be loaded.');
    return null;
  }
}
function petalhubOrderMailContent($order, $heading, $intro, $paymentMessage){
  $itemRows = '';
  $textItems = array();
  $wrapTotal = 0;
  $itemsTotal = 0;
  foreach ($order['items'] as $item){
    $name = petalhubMailEscape($item['name']);
    $qty = (int)$item['qty'];
    $lineTotal = (float)$item['price'] * $qty;
    $itemWrapFee = (float)$item['wrap_fee'];
    $wrapTotal += $itemWrapFee;
    $itemsTotal += $lineTotal + $itemWrapFee;
    $itemRows .= '<tr><td style="padding:10px 8px;border-bottom:1px solid #eee">' . $name . '</td><td style="padding:10px 8px;border-bottom:1px solid #eee;text-align:center">' . $qty . '</td><td style="padding:10px 8px;border-bottom:1px solid #eee;text-align:right">PHP ' . petalhubMailMoney($lineTotal) . '</td></tr>';
    $textItems[] = $item['name'] . ' x ' . $qty . ' - PHP ' . petalhubMailMoney($lineTotal);
  }
  $subtotal = isset($order['subtotal']) ? (float)$order['subtotal'] : $itemsTotal;
  if ($wrapTotal > 0){
    $itemRows .= '<tr><td colspan="2" style="padding:10px 8px;border-bottom:1px solid #eee">Wrapping</td><td style="padding:10px 8px;border-bottom:1px solid #eee;text-align:right">PHP ' . petalhubMailMoney($wrapTotal) . '</td></tr>';
    $textItems[] = 'Wrapping - PHP ' . petalhubMailMoney($wrapTotal);
  }
  $itemRows .= '<tr><td colspan="2" style="padding:10px 8px;border-bottom:1px solid #eee"><strong>Subtotal</strong></td><td style="padding:10px 8px;border-bottom:1px solid #eee;text-align:right"><strong>PHP ' . petalhubMailMoney($subtotal) . '</strong></td></tr>';
  $textItems[] = 'Subtotal - PHP ' . petalhubMailMoney($subtotal);
  $deliveryFee = $order['fulfillment'] === 'delivery' && isset($order['delivery_fee']) ? (float)$order['delivery_fee'] : 0;
  if (!isset($order['delivery_fee']) && $order['fulfillment'] === 'delivery' && round((float)$order['total'] - $itemsTotal, 2) === petalhubDeliveryFee())
    $deliveryFee = petalhubDeliveryFee();
  if ($deliveryFee > 0){
    $itemRows .= '<tr><td colspan="2" style="padding:10px 8px;border-bottom:1px solid #eee">Delivery fee</td><td style="padding:10px 8px;border-bottom:1px solid #eee;text-align:right">PHP ' . petalhubMailMoney($deliveryFee) . '</td></tr>';
    $textItems[] = 'Delivery fee - PHP ' . petalhubMailMoney($deliveryFee);
  }
  $address = $order['fulfillment'] === 'delivery'
    ? implode(', ', array_filter(array($order['street'], $order['city'], $order['zip']), function($part){ return $part !== ''; }))
    : 'Pickup at the shop';
  $payment = $order['payment'];
  $reference = $order['gcash_ref'] !== null && $order['gcash_ref'] !== '' ? (string)$order['gcash_ref'] : '';
  $name = $order['customer'] !== '' ? $order['customer'] : 'Customer';
  $html = '<div style="font-family:Arial,sans-serif;max-width:620px;margin:0 auto;padding:28px;color:#382922;background:#fffcf5;border:1px solid #eadfd1;border-radius:16px">' .
    '<p style="color:#8b3d45;font-weight:bold;letter-spacing:2px">PETALHUB</p><h1 style="font-size:24px">' . petalhubMailEscape($heading) . '</h1>' .
    '<p>Hello ' . petalhubMailEscape($name) . ',</p><p>' . petalhubMailEscape($intro) . '</p>' .
    '<p><strong>Order number: ' . petalhubMailEscape($order['code']) . '</strong></p>' .
    '<table style="width:100%;border-collapse:collapse"><thead><tr><th style="padding:8px;text-align:left">Item</th><th style="padding:8px">Qty</th><th style="padding:8px;text-align:right">Amount</th></tr></thead><tbody>' . $itemRows . '</tbody></table>' .
    '<p style="text-align:right;font-size:18px"><strong>Total: PHP ' . petalhubMailMoney($order['total']) . '</strong></p>' .
    '<p><strong>Fulfillment:</strong> ' . petalhubMailEscape($order['fulfillment'] === 'delivery' ? 'Delivery' : 'Pickup') . '<br><strong>' .
    ($order['fulfillment'] === 'delivery' ? 'Delivery address' : 'Pickup') . ':</strong> ' . petalhubMailEscape($address) . '<br><strong>Payment:</strong> ' . petalhubMailEscape($payment) . '</p>' .
    ($reference !== '' ? '<p><strong>GCash reference:</strong> ' . petalhubMailEscape($reference) . '</p>' : '') .
    '<p>' . petalhubMailEscape($paymentMessage) . '</p><p style="color:#74675f;font-size:13px">Keep this email for your order records. You can also view order updates in your PetalHub account.</p></div>';
  $text = "PETALHUB\n" . $heading . "\n\nHello " . $name . ",\n" . $intro . "\n\nOrder number: " . $order['code'] .
    "\n\n" . implode("\n", $textItems) . "\nTotal: PHP " . petalhubMailMoney($order['total']) .
    "\nFulfillment: " . ($order['fulfillment'] === 'delivery' ? 'Delivery' : 'Pickup') .
    "\n" . ($order['fulfillment'] === 'delivery' ? 'Delivery address: ' : 'Pickup: ') . $address .
    "\nPayment: " . $payment . ($reference !== '' ? "\nGCash reference: " . $reference : '') .
    "\n\n" . $paymentMessage . "\n\nKeep this email for your order records.";
  return array('html' => $html, 'text' => $text);
}
function sendOrderConfirmationEmail($code){
  $order = petalhubOrderMailData($code);
  if (!$order) return false;
  if ($order['payment_status'] === 'awaiting'){
    $paymentMessage = 'Your GCash payment details were submitted and are awaiting shop verification. This email confirms the order; it is not a payment receipt.';
  } else {
    $paymentMessage = 'Cash payment is due at ' . ($order['fulfillment'] === 'delivery' ? 'delivery' : 'pickup') . '. This email confirms the order; it is not a payment receipt.';
  }
  $content = petalhubOrderMailContent($order, 'Order received', 'We received your order and will prepare it according to its fulfillment details.', $paymentMessage);
  return sendPetalHubEmail($order['email'], 'Your PetalHub order ' . $order['code'] . ' is received', $content['html'], $content['text']);
}
function sendOrderPaymentVerifiedEmail($code){
  $order = petalhubOrderMailData($code);
  if (!$order) return false;
  $paidAt = $order['paid_at'] ? date('M j, Y g:i A', strtotime($order['paid_at'])) : '';
  $paymentMessage = 'The shop verified your GCash payment' . ($paidAt !== '' ? ' on ' . $paidAt : '') . '. Your order is confirmed and will be prepared now.';
  $content = petalhubOrderMailContent($order, 'Payment verified', 'Your GCash payment has been verified by the shop.', $paymentMessage);
  return sendPetalHubEmail($order['email'], 'Payment confirmed for PetalHub order ' . $order['code'], $content['html'], $content['text']);
}
function sendOrderCompletedEmail($code){
  $order = petalhubOrderMailData($code);
  if (!$order) return false;
  $content = petalhubOrderMailContent($order, 'Order completed', 'Your order has been marked completed. Thank you for choosing PetalHub.', 'Thank you for shopping with PetalHub. We hope you enjoy your flowers.');
  return sendPetalHubEmail($order['email'], 'Your PetalHub order ' . $order['code'] . ' is completed', $content['html'], $content['text']);
}

/* ---------- shaping rows for the website ---------- */
function pub($p){
  $qty = (int)$p['qty']; $on = $qty > 0 && (!isset($p['available']) || (int)$p['available'] === 1);
  return array('id' => (int)$p['id'], 'name' => isset($p['name']) ? $p['name'] : '', 'price' => (float)$p['price'],
    'description' => isset($p['description']) ? $p['description'] : '', 'qty' => $qty, 'unit' => $p['unit'], 'available' => $on,
    'imagePath' => isset($p['image_path']) ? $p['image_path'] : '',
    'stock' => ($on && $qty > 0) ? $qty . ' ' . $p['unit'] : 'Out of stock');
}
function toOrders($rs){
  if (!$rs) return array();
  $codes = array_map(function($r){ return $r['code']; }, $rs);
  $items = rows('SELECT order_code, product_id AS id, name, qty, price, line_key, line_name, arrangement, line_qty, wrap_design, wrap_color, wrap_notes, wrap_fee FROM order_items WHERE order_code IN (' . marks(count($codes)) . ') ORDER BY id', $codes);
  $itemsByOrder = array();
  foreach ($items as $i){
    if (!isset($itemsByOrder[$i['order_code']])) $itemsByOrder[$i['order_code']] = array();
    $itemsByOrder[$i['order_code']][] = array(
      'id' => (int)$i['id'], 'name' => $i['name'], 'qty' => (int)$i['qty'], 'price' => (float)$i['price'],
      'lineKey' => $i['line_key'], 'lineName' => $i['line_name'], 'arrangement' => $i['arrangement'],
      'lineQty' => (int)$i['line_qty'], 'wrapDesign' => $i['wrap_design'], 'wrapColor' => $i['wrap_color'],
      'wrapNotes' => $i['wrap_notes'], 'wrapFee' => (float)$i['wrap_fee']);
  }
  $out = array();
  foreach ($rs as $r){
    $out[] = array('code' => $r['code'], 'date' => iso($r['created_at']), 'customer' => $r['customer'], 'email' => $r['email'], 'subtotal' => (float)$r['subtotal'], 'deliveryFee' => (float)$r['delivery_fee'], 'total' => (float)$r['total'], 'status' => $r['status'],
      'items' => isset($itemsByOrder[$r['code']]) ? $itemsByOrder[$r['code']] : array(), 'fulfillment' => $r['fulfillment'], 'address' => array('street' => $r['street'], 'city' => $r['city'], 'zip' => $r['zip']),
      'customerPhone' => isset($r['customer_phone']) ? $r['customer_phone'] : '',
      'riderId' => isset($r['rider_id']) && $r['rider_id'] !== null ? (int)$r['rider_id'] : null,
      'riderName' => isset($r['assigned_rider_name']) ? $r['assigned_rider_name'] : '',
      'riderPhone' => isset($r['assigned_rider_phone']) ? $r['assigned_rider_phone'] : '',
      'payment' => $r['payment'],
      'paymentStatus' => isset($r['payment_status']) ? $r['payment_status'] : 'not_required',
      'gcashRef' => isset($r['gcash_ref']) ? $r['gcash_ref'] : null,
      'hasProof' => !empty($r['payment_proof']),
      'paymentNote' => isset($r['payment_note']) ? $r['payment_note'] : '',
      'paidAt' => !empty($r['paid_at']) ? iso($r['paid_at']) : null);
  }
  return $out;
}
/* ---------- saved cart (cart_items): one row per flower of each cart line, so the cart survives logout and login ---------- */
function cartLinesFor($uid){
  $lines = array();
  foreach (rows('SELECT product_id, qty, line_key, arrangement, line_qty, wrap_design, wrap_color, wrap_notes FROM cart_items WHERE user_id = ? ORDER BY id', array($uid)) as $r){
    $k = $r['line_key'];
    $per = max(1, (int)$r['line_qty']);
    if (!isset($lines[$k])) $lines[$k] = array('lineId' => $k, 'qty' => $per, 'arrangementType' => $r['arrangement'],
      'wrapDesign' => $r['wrap_design'], 'wrapColor' => $r['wrap_color'], 'wrapNotes' => $r['wrap_notes'], 'flowers' => array());
    $lines[$k]['flowers'][] = array('id' => (int)$r['product_id'], 'qty' => max(1, (int)round($r['qty'] / $per)));
  }
  return array_values($lines);
}
function replaceCart($uid, $items){
  $designs = array('pink-elegance', 'classic-kraft', 'midnight-luxury', 'minimalist-white');
  if (!is_array($items) || count($items) > 200) fail(400, 'Your cart is too large.');
  $lines = array(); $ids = array();
  foreach ($items as $i){
    $id = get($i, 'id'); $n = get($i, 'qty'); $lq = get($i, 'line_qty', 1);
    if (!is_numeric($id) || !isInt($id + 0) || !is_numeric($n) || !isInt($n + 0) || $n < 1 || $n > 99 || !is_numeric($lq) || !isInt($lq + 0) || $lq < 1 || $lq > 99) fail(400, 'Invalid cart.');
    $id = (int)$id; $n = (int)$n; $lq = (int)$lq;
    if ($n % $lq !== 0) fail(400, 'Invalid cart quantity.');
    $key = str(get($i, 'line_key'), 60);
    if ($key === '') fail(400, 'Invalid cart.');
    $arr = get($i, 'arrangement', 'single');
    if (!in_array($arr, array('single', 'bouquet', 'custom'), true)) fail(400, 'Invalid arrangement.');
    $wd = str(get($i, 'wrap_design'), 40);
    if ($wd !== '' && ($arr === 'single' || !in_array($wd, $designs, true))) fail(400, 'Invalid wrapping option.');
    $row = array('id' => $id, 'qty' => $n, 'name' => str(get($i, 'line_name'), 80), 'arr' => $arr, 'lq' => $lq, 'wd' => $wd,
      'wc' => str(get($i, 'wrap_color'), 100), 'wn' => str(get($i, 'wrap_notes'), 300));
    if (isset($lines[$key]) && ($lines[$key][0]['arr'] !== $arr || $lines[$key][0]['lq'] !== $lq || $lines[$key][0]['wd'] !== $wd)) fail(400, 'Invalid cart grouping.');
    $lines[$key][] = $row;
    $ids[$id] = $id;
  }
  $valid = array();
  if ($ids) foreach (rows('SELECT id FROM products WHERE id IN (' . marks(count($ids)) . ') AND active = 1', array_values($ids)) as $p) $valid[(int)$p['id']] = true;
  $marks = array(); $args = array();
  foreach ($lines as $key => $flowers){
    $seen = array(); $ok = true;
    foreach ($flowers as $f){
      if (!isset($valid[$f['id']]) || isset($seen[$f['id']])){ $ok = false; break; }
      $seen[$f['id']] = true;
    }
    if (!$ok) continue; // a flower that no longer exists removes the whole line instead of silently changing the bouquet
    foreach ($flowers as $f){
      $marks[] = '(' . marks(10) . ')';
      $args = array_merge($args, array($uid, $f['id'], $f['qty'], $key, $flowers[0]['name'], $flowers[0]['arr'], $flowers[0]['lq'],
        $flowers[0]['wd'] === '' ? null : $flowers[0]['wd'], $flowers[0]['wc'], $flowers[0]['wn']));
    }
  }
  inTx(function() use ($uid, $marks, $args){
    q('DELETE FROM cart_items WHERE user_id = ?', array($uid));
    if ($marks) q('INSERT INTO cart_items (user_id, product_id, qty, line_key, line_name, arrangement, line_qty, wrap_design, wrap_color, wrap_notes) VALUES ' . implode(',', $marks), $args);
  });
}

function inTx($fn){
  $pdo = db(); $pdo->beginTransaction();
  try { $out = $fn(); $pdo->commit(); return $out; }
  catch (Exception $e) { if ($pdo->inTransaction()) $pdo->rollBack(); throw $e; }
}

/* ---------- the API ---------- */
function handle(){
  $m = $_SERVER['REQUEST_METHOD'];
  $route = '/' . trim(isset($_GET['route']) ? $_GET['route'] : '', '/');
  $FLOW = array('Pending', 'Preparing', 'Ready', 'Completed');
  db();
  ensureAdmin();


  require __DIR__ . '/routes/catalog.php';
  require __DIR__ . '/routes/accounts.php';
  require __DIR__ . '/routes/orders.php';
  require __DIR__ . '/routes/admin.php';
  fail(404, 'Not found.');
}

function runApi($setupOnly){
  try {
    if ($setupOnly){
      db();
      ensureSetup();
      send(200, array('success' => true, 'message' => 'Database setup and migrations completed.'));
    }
    handle();
  } catch (ApiError $e) { send($e->getCode() ?: 500, array('error' => $e->getMessage())); }
  catch (Throwable $e) {
    error_log('PetalHub: ' . $e->getMessage() . ' (' . basename($e->getFile()) . ':' . $e->getLine() . ')');
    // PH_DEBUG (config.php) shows the real reason when enabled; disable it on public deployments.
    $detail = (!defined('PH_DEBUG') || PH_DEBUG) ? ' ' . $e->getMessage() . ' [' . basename($e->getFile()) . ':' . $e->getLine() . ']' : '';
    send(500, array('error' => 'Server error.' . $detail));
  }
}
