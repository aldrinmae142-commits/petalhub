<?php
if (!defined('PETALHUB_API_ENTRY')) { http_response_code(404); exit; }

/* Customer order history, updates, and checkout routes. */
  if ($m === 'GET' && $route === '/orders/mine'){
    if (!$me) fail(401, 'Please log in.');
    send(200, toOrders(rows("SELECT o.*, CONCAT_WS(' ', NULLIF(u.fname, ''), NULLIF(u.mname, ''), NULLIF(u.lname, '')) AS customer, u.email FROM orders o JOIN users u ON u.id = o.user_id WHERE o.user_id = ? ORDER BY o.created_at DESC, o.code DESC", array($me['id']))));
  }
  if ($m === 'GET' && $route === '/orders/mine/updates'){
    if (!$me) fail(401, 'Please log in.');
    send(200, rows("SELECT code, status, fulfillment, payment_status AS paymentStatus, payment_note AS paymentNote FROM orders WHERE user_id = ? ORDER BY created_at DESC, code DESC", array($me['id'])));
  }

  if ($m === 'POST' && $route === '/orders'){
    if (!$me) fail(401, 'Please log in to place an order.');
    $b = body(2800000); $want = array(); $requested = array(); $lineMap = array(); $its = get($b, 'items');
    if (!is_array($its) || !count($its) || count($its) > 50) fail(400, 'Your cart is empty.');
    $wrapPrices = array('pink-elegance' => 75.00, 'classic-kraft' => 50.00, 'midnight-luxury' => 80.00, 'minimalist-white' => 45.00);
    foreach ($its as $index => $i){
      $id = get($i, 'id'); $n = get($i, 'qty');
      if (!is_numeric($id) || !is_numeric($n) || !isInt($id + 0) || !isInt($n + 0) || $n < 1 || $n > 99) fail(400, 'Invalid cart.');
      $id = (int)$id; $arrangement = get($i, 'arrangement', 'single');
      if (!in_array($arrangement, array('single', 'bouquet', 'custom'), true)) fail(400, 'Invalid arrangement.');
      $lineQty = get($i, 'line_qty', $n);
      if (!is_numeric($lineQty) || !isInt($lineQty + 0) || $lineQty < 1 || $lineQty > 99) fail(400, 'Invalid cart quantity.');
      $lineKey = str(get($i, 'line_key'), 60);
      if ($lineKey === '') $lineKey = 'legacy-' . $index;
      $wrapDesign = str(get($i, 'wrap_design'), 40);
      if ($wrapDesign !== '' && ($arrangement === 'single' || !isset($wrapPrices[$wrapDesign]))) fail(400, 'Invalid wrapping option.');
      $line = array(
        'line_key' => $lineKey,
        'line_name' => str(get($i, 'line_name'), 80),
        'arrangement' => $arrangement,
        'line_qty' => (int)$lineQty,
        'wrap_design' => $wrapDesign === '' ? null : $wrapDesign,
        'wrap_color' => str(get($i, 'wrap_color'), 100),
        'wrap_notes' => str(get($i, 'wrap_notes'), 300)
      );
      if (isset($lineMap[$lineKey]) && $lineMap[$lineKey] !== $line) fail(400, 'Invalid cart grouping.');
      $lineMap[$lineKey] = $line;
      $requested[] = array('id' => $id, 'qty' => (int)$n, 'line' => $line);
      $want[$id] = (isset($want[$id]) ? $want[$id] : 0) + (int)$n;
    }
    $f = get($b, 'fulfillment'); $delivery = $f === 'delivery';
    if (!$delivery && $f !== 'pickup') fail(400, 'Choose pickup or delivery.');
    $a = get($b, 'address', array());
    $ad = $delivery ? array('street' => str(get($a, 'street'), 200), 'city' => str(get($a, 'city'), 100), 'zip' => str(get($a, 'zip'), 20), 'phone' => str(get($a, 'phone'), 30)) : array('street' => '', 'city' => '', 'zip' => '', 'phone' => '');
    if ($delivery && ($ad['street'] === '' || $ad['city'] === '')) fail(400, 'Enter a delivery address.');
    if ($delivery && !preg_match('/^09[0-9]{9}$/', $ad['phone'])) fail(400, 'Enter an 11-digit Philippine mobile number starting with 09.');
    $payMap = array('gcash' => 'GCash (QR)', 'cash' => $delivery ? 'Cash on delivery' : 'Cash on pickup');
    $pk = get($b, 'payment'); $pay = is_string($pk) && isset($payMap[$pk]) ? $payMap[$pk] : null;
    if (!$pay) fail(400, 'Choose a payment method.');
    // GCash QR: the customer pays by scanning the shop's QR code, then submits the 13-digit reference number from the GCash receipt.
    // The order is saved as "awaiting verification" and the admin must verify the payment before it can move forward.
    $isGcash = $pk === 'gcash'; $ref = null; $proofImage = null;
    if ($isGcash){
      $ref = preg_replace('/\D/', '', (string)get($b, 'gcashRef', ''));
      if (strlen($ref) !== 13) fail(400, 'Enter the 13-digit GCash reference number shown on your payment receipt.');
      $proofIn = get($b, 'proof');
      if (is_string($proofIn) && $proofIn !== '') $proofImage = decodeImage($proofIn, 2000000);
    }
    $key = str(get($b, 'key'), 60); if ($key === '') $key = null;
    $existing = function() use ($me, $key){ return $key ? row('SELECT code FROM orders WHERE user_id = ? AND checkout_key = ?', array($me['id'], $key)) : null; };
    try {
      $out = inTx(function() use ($want, $requested, $lineMap, $wrapPrices, $existing, $me, $f, $ad, $pay, $key, $isGcash, $ref){
        $ids = array_keys($want); sort($ids);
        $prods = rows('SELECT id, name, price, qty, available FROM products WHERE id IN (' . marks(count($ids)) . ') AND active = 1 ORDER BY id FOR UPDATE', $ids);
        $dup = $existing(); // checked again after the product lock, so two simultaneous requests cannot both pass
        if ($dup) return array('code' => $dup['code'], 'duplicate' => true);
        if (count($prods) !== count($ids)) fail(400, 'Unknown product.');
        $total = 0;
        foreach ($prods as $p){
          if (!(int)$p['available']) fail(409, $p['name'] . ' is out of stock.');
          if ($want[(int)$p['id']] > $p['qty']) fail(409, $p['qty'] ? 'Only ' . $p['qty'] . ' left of ' . $p['name'] . '.' : $p['name'] . ' is out of stock.');
          $total += (float)$p['price'] * $want[(int)$p['id']];
        }
        foreach ($lineMap as $line) if ($line['wrap_design']) $total += $wrapPrices[$line['wrap_design']] * $line['line_qty'];
        $total = round($total, 2);
        do { $oc = 'PH-' . random_int(100000, 999999); } while (row('SELECT 1 FROM orders WHERE code = ?', array($oc)));
        q('INSERT INTO orders (code, user_id, total, fulfillment, street, city, zip, customer_phone, payment, checkout_key, payment_status, gcash_ref) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)',
          array($oc, $me['id'], $total, $f, $ad['street'], $ad['city'], $ad['zip'], $ad['phone'], $pay, $key, $isGcash ? 'awaiting' : 'not_required', $ref));
        $productsById = array();
        foreach ($prods as $p) $productsById[(int)$p['id']] = $p;
        $feesApplied = array();
        $itemRows = array();
        $itemArgs = array();
        foreach ($requested as $item){
          $p = $productsById[$item['id']]; $line = $item['line'];
          $fee = 0;
          if (!isset($feesApplied[$line['line_key']]) && $line['wrap_design']){
            $fee = $wrapPrices[$line['wrap_design']] * $line['line_qty'];
            $feesApplied[$line['line_key']] = true;
          }
          $lineName = $line['line_name'] !== '' ? $line['line_name'] : $p['name'];
          $itemRows[] = '(' . marks(13) . ')';
          $itemArgs = array_merge($itemArgs, array($oc, $p['id'], $p['name'], $item['qty'], $p['price'], $line['line_key'], $lineName, $line['arrangement'], $line['line_qty'], $line['wrap_design'], $line['wrap_color'], $line['wrap_notes'], $fee));
        }
        q('INSERT INTO order_items (order_code, product_id, name, qty, price, line_key, line_name, arrangement, line_qty, wrap_design, wrap_color, wrap_notes, wrap_fee) VALUES ' . implode(',', $itemRows), $itemArgs);
        $stockRows = array();
        $stockArgs = array();
        foreach ($prods as $p){
          $used = $want[(int)$p['id']];
          $stockRows[] = 'SELECT ? AS id, ? AS used, ? AS new_available';
          $stockArgs = array_merge($stockArgs, array($p['id'], $used, (int)$p['qty'] === $used ? 0 : (int)$p['available']));
        }
        q('UPDATE products p JOIN (' . implode(' UNION ALL ', $stockRows) . ') requested ON requested.id = p.id SET p.qty = p.qty - requested.used, p.available = requested.new_available', $stockArgs);
        return array('code' => $oc);
      });
    } catch (PDOException $e) {
      $dupInfo = isset($e->errorInfo[1]) && $e->errorInfo[1] == 1062;
      if ($dupInfo && strpos($e->getMessage(), 'uq_orders_gcash_ref') !== false) fail(409, 'This GCash reference number was already used for another order. Please check the number on your receipt.');
      if ($dupInfo && $key && ($dup = $existing())) $out = array('code' => $dup['code'], 'duplicate' => true);
      else throw $e;
    }
    // the proof-of-payment picture is saved after the order exists, under a random name, and can only be opened by the admin
    if ($proofImage && empty($out['duplicate'])){
      protectPaymentDirs();
      $file = $out['code'] . '-' . bin2hex(random_bytes(6)) . '.' . $proofImage['ext'];
      if (@file_put_contents(paymentDir('proofs') . '/' . $file, $proofImage['bin']) !== false) q('UPDATE orders SET payment_proof = ? WHERE code = ?', array($file, $out['code']));
    }
    $out['paymentStatus'] = $isGcash ? 'awaiting' : 'not_required';
    send(!empty($out['duplicate']) ? 200 : 201, $out);
  }
