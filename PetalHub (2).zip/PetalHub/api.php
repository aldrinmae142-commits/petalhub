<?php
if (!defined('PETALHUB_API_ENTRY')) define('PETALHUB_API_ENTRY', true);
if (!defined('PETALHUB_ROOT')) define('PETALHUB_ROOT', __DIR__);

require_once __DIR__ . '/api/core.php';
runApi(defined('PETALHUB_SETUP_MODE') && PETALHUB_SETUP_MODE);
